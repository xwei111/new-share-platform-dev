import React, { PropTypes, Component } from 'react';
import { BrandlerBoard } from 'components/admin/BrandlerAnalysis';

export default class BrandlerBoardContainer extends Component {
  render() {
    return (
      <BrandlerBoard/>
    );
  }
}
