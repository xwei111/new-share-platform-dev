export AddTagContainer from './InitActivities/AddTagContainer.jsx';
export CouponInfoContainer from './InitActivities/CouponInfoContainer.jsx';
export ActiveMoudleContainer from './InitActivities/ActiveMoudleContainer.jsx';
export SubResultContainer from './InitActivities/SubResultContainer.jsx';
export PredictionContainer from './PredictionContainer.jsx';
export ResultContainer from './ResultContainer.jsx';
