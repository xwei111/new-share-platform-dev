export PieChartsTotal from './PieChartsTotal.jsx';
export PieChartsMarkets from './PieChartsMarkets.jsx';
export PieChartsAvg from './PieChartsAvg.jsx';
export AreasMapChart from './AreasMapChart.jsx';
export AreasHistogramChart from './AreasHistogramChart.jsx';
export CityHistogramChart from './CityHistogramChart.jsx';
export FansNumberChart from './FansNumberChart.jsx';