import React from 'react';
import styles from './styles.css';

export default function Presentation() {
  return (
    <div className={styles.showPic}>
      <img src="https://h5cspm.miyapay.com/h5/images/coupon1.png" alt=""/>
    </div>
  );
};
