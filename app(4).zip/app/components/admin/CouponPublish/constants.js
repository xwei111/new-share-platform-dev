export const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 14 }
};
